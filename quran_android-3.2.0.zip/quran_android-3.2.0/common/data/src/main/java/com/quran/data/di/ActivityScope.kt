package com.quran.data.di

import javax.inject.Scope

@Scope
annotation class ActivityScope
