package com.quran.data.constant

object DependencyInjectionConstants {
  const val CURRENT_PAGE_TYPE = "CURRENT_PAGE_TYPE"
}
