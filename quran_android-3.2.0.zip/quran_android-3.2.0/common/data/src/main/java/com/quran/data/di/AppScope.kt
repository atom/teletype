package com.quran.data.di

/**
 * Singleton/Application level scope
 */
abstract class AppScope private constructor()
