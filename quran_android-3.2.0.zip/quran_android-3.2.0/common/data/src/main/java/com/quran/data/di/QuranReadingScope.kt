package com.quran.data.di

/**
 * Activity/PagerActivity scope for a Quran reading session.
 */
abstract class QuranReadingScope private constructor()
