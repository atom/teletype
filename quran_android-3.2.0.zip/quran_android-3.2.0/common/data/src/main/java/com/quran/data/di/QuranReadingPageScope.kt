package com.quran.data.di

/**
 * scope for a Quran page
 */
abstract class QuranReadingPageScope private constructor()
